export default {
  datos: [
    {
      mes: 'Noviembre',
      salarios: 11,
      provisiones: 8.6,
      seguridad: 3.2,
    },
    {
      mes: 'Diciembre',
      salarios: 31.5,
      provisiones: 11.6,
      seguridad: 7.2,
    },
    {
      mes: 'Enero',
      salarios: 28.4,
      provisiones: 5.3,
      seguridad: 1.3,
    },
    {
      mes: 'Febrero',
      salarios: 25,
      provisiones: 8.8,
      seguridad: 2.2,
    },
    {
      mes: 'Marzo',
      salarios: 25.1,
      provisiones: 7.6,
      seguridad: 1.8,
    },
    {
      mes: 'Abril',
      salarios: 26.3,
      provisiones: 7.5,
      seguridad: 1.8,
    },
  ],
}
