export default {
    operadoresPago: [
        {llave:'Aportes en Línea', valor:'Aportes en Línea'},
        {llave:'ARUS', valor:'ARUS'},
        {llave:'Asopagos', valor:'Asopagos'},
        {llave:'Banco Agrario', valor:'Banco Agrario'},
        {llave:'Coomeva', valor:'Coomeva'},
        {llave:'Mi Planilla', valor:'Mi Planilla'},
        {llave:'Pila Fácil', valor:'Pila Fácil'},
        {llave:'Simple', valor:'Simple'},
        {llave:'SOI', valor:'SOI'},
    ]
}