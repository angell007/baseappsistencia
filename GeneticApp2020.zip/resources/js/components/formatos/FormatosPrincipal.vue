<template>
  <div class="container">
    <h1 class="font-weight-bold">Formatos</h1>
    <div class="row">
      <div class="alert alert-secondary col-md-12 text-center">
        <div class="warning">
          <div class="row mb-1">
            <i class="simple-icon-info warning-icon mx-auto"></i>
          </div>
        </div>
        <p
          class="font-weight-bold"
        >Acá se subirán formatos para permisos, incapacidades, novedades, etc.</p>
        <p class="font-weight-bold">
          En este momento no está disponible este módulo, estamos trabajando en ello !
          <i
            class="simple-icon-like warning-icon"
          ></i>
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {}
</script>

<style scoped>
.warning-icon {
  font-size: 2rem;
}
</style>
