<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ContableBancoCaja extends Model
{
    protected $table = 'contable_banco_caja';
    protected $guarded = ['id'];
}
