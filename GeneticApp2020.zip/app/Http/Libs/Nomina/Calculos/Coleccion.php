<?php

namespace App\Http\Libs\Nomina\Calculos;

interface Coleccion
{
    public function crearColeccion();
}
