<?php

namespace App\Http\Controllers;

class ValidacionExtrasController extends Controller
{
    public function getExtrasValidadas($fechaInicio, $fechaFin)
    { }
}
